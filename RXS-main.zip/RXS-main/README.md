# RXS
The better version of redXscript (no longer supported)

Dec 11, 2023 marks the end of support for RXS. This project was the first ever HTML page I have ever made and I think its time to put it to rest. 
I made this site originally just as a test and demo to show to some friends of mine. However; after adding minecraft 1.5 and later 1.8 to the site, this site exploded in popularity in unintended ways. This site was never meant to get over 100 views, so thank ya'll for that. 
I, despite wanting to archive this github page and forgetting about it, wiill continue adding security updates every like year or so so it doesn't get weird ads and stuff like that butv in terms of content updates, this will be final one, I made a new site a while ago for minecraft so now the og RXS minecraft page links you to there instead of the game. Thank youa ll again for the views and support but this it.
-Eli
